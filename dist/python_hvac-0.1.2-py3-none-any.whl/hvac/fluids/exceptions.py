class CoolPropWarning(Warning):
    pass


class CoolPropError(Exception):
    pass


class CoolPropMixtureError(CoolPropError):
    pass
