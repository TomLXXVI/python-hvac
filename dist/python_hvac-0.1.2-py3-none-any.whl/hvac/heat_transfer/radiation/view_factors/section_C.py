"""
VIEW FACTORS / SECTION C
Factors from finite areas to finite areas.
"""
import numpy as np
from hvac import Quantity


def view_factor_C61(b: Quantity, a: Quantity) -> float:
    """
    C-61: Exterior of infinitely long cylinder (surface 1) to symmetrically
    placed infinitely long parallel rectangle (surface 2).

    Parameters
    ----------
    b:
        width of the rectangle
    a:
        distance between the rectangle and the center of the cylinder.
    """
    b = b.to('m').m
    a = a.to('m').m
    B = (b / 2) / a
    F12 = (1 / np.pi) * np.arctan(B)
    return F12


