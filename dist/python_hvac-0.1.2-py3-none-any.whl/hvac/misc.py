"""
Module for miscellaneous functions. 
"""


def print_doc_string(doc_string: str) -> None:
    """Prints a docstring with all lines justified to the left."""
    lines = doc_string.splitlines(keepends=True)
    if len(lines) == 1:
        print(doc_string)
        return
    if lines[0] == '\n':
        lines = lines[1:]
    leading_space_counts = []
    for line in lines:
        count = 0
        for char in line:
            if char == ' ':
                count += 1
            else:
                leading_space_counts.append(count)
                break
    leading_space_counts = list(set(sorted(leading_space_counts)))
    if leading_space_counts[0] == 0:
        length = leading_space_counts[1]
    else:
        length = leading_space_counts[0]
    new_lines = []
    for line in lines:
        new_line = line.removeprefix(' ' * length)
        new_lines.append(new_line)
    new_doc_string = ''.join(new_lines)
    print(new_doc_string)
