from .section_C import view_factor_C61
