from .time_conversion import convert_to_clock_time, convert_to_solar_seconds

